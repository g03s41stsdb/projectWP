<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>
<div class="w3-container"style="width:80%;margin:0 auto;" >
<div class="w3-bar w3-border w3-light-blue ">
  <h1 class="w3-center w3-container w3-purple">Staff Training System(STS) - ADMIN</h1>
  <a href="../menu/staffMenu.php" class="w3-bar-item w3-button w3-hover-blue ">Home</a>
  <a href="../staff/StaffInfoForm.php" class="w3-bar-item w3-button w3-hover-blue">Attend Training</a>
  <a href="../staff/Stafflist.php" class="w3-bar-item w3-button w3-hover-blue">Booking History</a>
  <a href="../staff/staffInfo.php" class="w3-bar-item w3-button w3-hover-blue">Update My Profiles</a>
  <a href="../login/Logout.php" class="w3-bar-item w3-button w3-right w3-hover-blue">Logout</a>
</div>
</div>
</body>
</html>
