<html>
   <head>
   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">;
   </head>
</html>
<?php
//staffMenu.php

session_start();
if (!(isset($_SESSION['UserId']) && $_SESSION['UserId'] != '')) {
	header ("Location: login/LoginForm.php");
}
 include "../staff/staff.php";
 $staffID = $_SESSION['UserId'];
 $curTime = $_SESSION['curTime'];
 $staffInfoRow = getCustomerInformation($staffID);
 echo '<h1 class="w3-center w3-container w3-purple"><center>Welcome to Staff Training</center></h1>';
 echo "<h4><b><center>User: </b>".$staffID."</center></h4>";
 //echo "<h5><center>Welcome back</h5></center><h4><center>".$staffInfoRow['staffID'].'</center></h4>';
 echo "<h5><center><b>Welcome back</b></h5></center>
 <h4><center>".$staffInfoRow['firstName'].$staffInfoRow['lastName']."</center></h4>";
 $strTime = date("H:i A",$curTime) ;
 echo "<hr><h4><center><b>Log in time: </b>".$strTime."</center></h4>";
 
 
 //display the menu
 echo "<hr><h4><center><b>What would you like to do?</b></center></h4>";
 echo '<center><a href="#">Attend Training</a>';
 echo '<br>';
 echo '<a href="#">View My Training History</a>';
 echo '<br><a href="..\login\logout.php">Log out</a></center>';
  ?>
  <!--
<!DOCTYPE html>
<html>
   <body>
   <h1>Staff Training System(STS) - STAFF</h1>
    <br>
	  <a href="../staff/StaffInfoForm.php">Enter Information About Staff</a>
   </body>
   </html>
   
 
 