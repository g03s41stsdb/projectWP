<?php
include "staff.php";
print_r($_POST);
if(isSet($_POST['addButton']))
{
	addNewStaff();
	header('Location:Stafflist.php');
}else
{
	if(isSet($_POST['staffIdToDelete']));
	{
		deleteStaff();
		header('Location:Stafflist.php');
	}
}
?>