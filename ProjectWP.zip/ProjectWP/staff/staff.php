<?php
function addNewStaff()
{
		$con=mysqli_connect("localhost","web412023","web412023","g03s41stsdb");
		if(!$con)
	{
		echo "Error".mysqli_connect_error();
	}else
	{
		$staffId=$_POST['UserID'];
		$firstName=$_POST['firstName'];
		$lastName=$_POST['lastName'];
		$icNumber=$_POST['icNumber'];
		$dateOfBirth=$_POST['dateOfBirth'];
		$contactNumber=$_POST['contactNumber'];
		$email=$_POST['email'];
		$dateOfEmployment=$_POST['dateOfEmployment'];
		$position=$_POST['position'];
		$sql="INSERT INTO staff(staffId,firstName,lastName,icNumber,dateOfBirth,contactNumber,email,dateOfEmployment,position)
		VALUES('$staffId', '$firstName', '$lastName', '$icNumber','$dateOfBirth', '$contactNumber','$email','$dateOfEmployment','$position')";
		echo $sql;
		mysqli_query($con,$sql);
	}
}

function getListOfStaff()
{
	$con=mysqli_connect("localhost","web412023","web412023","g03s41stsdb");
	if(!$con)
	{
		echo 'Error'.mysqli_connect_error();
	}else
	{
		$sql='select * from staff order by staffId';
		$staffQry=mysqli_query($con,$sql);
		return $staffQry;
	}
}

function deleteStaff()
{
	$con=mysqli_connect("localhost","web412023","web412023","g03s41stsdb");
	if(!$con)
	{
		echo "Error".mysqli_connect_error();
	}else
	{
		$sql="delete from staff where staffId='".$_POST['staffIdToDelete']."'";
		mysqli_query($con,$sql);
	}
}
?>

<?php

function getCustomerInformation($staffId)
{
//create connection
$con=mysqli_connect("localhost","web412023","web412023","g03s41stsdb");
if(!$con)
	{
	echo  mysqli_connect_error(); 
	exit;
	}
$sql = "SELECT * from staff where staffID = '".$staffId."'";
$qry = mysqli_query($con,$sql);//run query
if(mysqli_num_rows($qry) == 1)
	{
	$row=mysqli_fetch_assoc($qry);
	return $row;
	}
else
	return false;
}

?>