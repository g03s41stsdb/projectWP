<!DOCTYPE.html>
<html>
    <body>
	    <h1>New Staff Infomation</h1>
		<br>
		<form action="processStaff.php" method="POST">
		1.StaffId:<input type="text" name="UserID">
		<br>
		2.FirstName:<input type="text" name="firstName">
		<br>
		3.LastName:<input type="text" name="lastName">
		<br>
		4.IcNumber:<input type="text" name="icNumber">
		<br>
		5.DateOfBirth:<input type="date" name="dateOfBirth">
		<br>
		6.ContractNumber:<input type="text" name="contactNumber">
		<br>
		7.Email:<input type="text" name="email">
		<br>
		8.DateOfEmployment:<input type="date" name="dateOfEmployment">
		<br>
		9.Position:<input type="text" name="position">
		<br>
		<br>
		<input type="submit" name="addButton" value="Save">
		<input type="reset" name="resetButton" value="Clear">
	</body>
</html>