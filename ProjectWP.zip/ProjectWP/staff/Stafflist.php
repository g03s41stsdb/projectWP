<!DOCTYPE html>
<html>
<head>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>
</head>

<?php
include "staff.php";
$staffQry=getListOfStaff();
echo '<table>';
    echo '<tr>';
	  echo '<th>No</th>';
		echo '<th>StaffId</th>';
		echo '<th>First Name</th>';
		echo '<th>Last Name</th>';
		echo '<th>IC-Number</th>';
		echo '<th>Date Of Birth</th>';
		echo '<th>Contact Number</th>';
		echo '<th>Email</th>';
		echo '<th>Date Of Employment</th>';
		echo '<th>Position</th>';
		echo '<th>Delete</th>';
    echo '</tr>';
$count=1;
while ($row=mysqli_fetch_assoc($staffQry))
{
	$UserId=$row['staffID'];
		echo '<tr>';
	  echo '<td>'.$count.'</td>';
	  echo '<td>'.$row['staffID'].'</td>';
		echo '<td>'.$row['firstName'].'</td>';
		echo '<td>'.$row['lastName'].'</td>';
		echo '<td>'.$row['icNumber'].'</td>';
		echo '<td>'.$row['dateOfBirth'].'</td>';
		echo '<td>'.$row['contactNumber'].'</td>';
		echo '<td>'.$row['email'].'</td>';
		echo '<td>'.$row['dateOfEmployment'].'</td>';
		echo '<td>'.$row['position'].'</td>';
		
		echo '<td>';
		  echo '<form action="processStaff.php" method="POST">';
			echo "<input type='hidden' name='staffIdToDelete' value='$staffId'>";
			echo '<input type="submit" value="Delete" name="deleteStaffButton">';
	echo '</tr>';
	$count++;
}
echo '</table>';	
?>
</html>