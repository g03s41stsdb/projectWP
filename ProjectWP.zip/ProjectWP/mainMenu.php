<!DOCTYPE html>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<html>

<?php
 echo '<title>Login Staff Training</title>';
 echo '<body>';
  echo '<div style="text-align:center">'; 
 echo '<h1 class="w3-center w3-container w3-purple">Login Staff Training</h1>';
 ?>
      <form class="w3-container" action="login/checkLogin.php" method="post">
          <br><br>
          <label><b>User ID</b></label>
          <input class="w3-input w3-border w3-margin-bottom" type="text"
           placeholder="Enter User ID" name="UserId" required><br>
          <label><b>Password</b></label>
          <input class="w3-input w3-border" type="password"
           placeholder="Enter Password" name="password" required><br>
          <button class="w3-button w3-block w3-teal w3-section w3-padding" type="submit" name="loginButton">Login</button><br><br><br><br>
      </form>
      <div>
        <h5>Don't have an account?</h5>
        <a class="w3-text-blue" href="login/register.html">Sign Up Here</a>
      </div>
				
  
<?php
 echo '</div>';

echo '</body>';
 ?>
 
 </html> 