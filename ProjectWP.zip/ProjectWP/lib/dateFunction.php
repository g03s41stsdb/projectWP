<?php
function getNamaHari($dayNo)
{

if($dayNo==1)
	{
	return 'AHAD';
	}
else if($dayNo ==2)
	 {
	 return 'ISNIN';
	 }
else if($dayNo ==3)
	 {
	 return 'SELASA';
	 }
	 else if($dayNo ==4)
	 {
	 return 'RABU';
	 }else if($dayNo ==5)
	 {
	 return 'KHAMIS';
	 }else if($dayNo ==6)
	 {
	 return 'JUMAAT';
	 }else if($dayNo ==7)
	 {
	 return 'SABTU';
	 }
 }
 
 function getNamaHariFromYmdFormat($dayNo)
{

if($dayNo==1)
	{
	return 'AHAD';
	}
else if($dayNo ==2)
	 {
	 return 'ISNIN';
	 }
else if($dayNo ==3)
	 {
	 return 'SELASA';
	 }
	 else if($dayNo ==4)
	 {
	 return 'RABU';
	 }else if($dayNo ==5)
	 {
	 return 'KHAMIS';
	 }else if($dayNo ==6)
	 {
	 return 'JUMAAT';
	 }else if($dayNo ==7)
	 {
	 return 'SABTU';
	 }
	 
	 
	 
	 }

	 ?>