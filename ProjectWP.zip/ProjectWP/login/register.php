
    <?php
      if (isset($_POST['register'])) {
        $conn = mysqli_connect('localhost', 'web412023', 'web412023', 'g03s41stsdb');
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        $UserId = $_POST['UserId'];
        $password = $_POST['password'];
        $rePassword = $_POST['rePassword'];
        $userType = $_POST['userType'];

        if($password == $rePassword){
          $sql = "INSERT INTO users (UserId, Password, userType) VALUES ('$UserId', '$password', '$userType')";
          if (mysqli_query($conn, $sql)) {
            header('Location:login.html');
            echo "Registration successful.";
          } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
        }else{
          echo 'Password does not match!';
        }
        

        //mysqli_close($conn);
      }
    ?>
  </body>
</html>
