<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php
session_start(); 
//checkLogin.php
include "user.php";
$_SESSION['UserId']=$_POST['UserId'];  
$_SESSION['password']=$_POST['password'];  
//$_SESSION['curTime']=time('G:i:sa');//get the login time
$_SESSION['curTime']=time();//get the login time


// username and password sent from form 
$UserId=$_POST['UserId']; 
$password=$_POST['password']; 


$isValidUser = validatePassword($UserId,$password);

if($isValidUser)
	{
	$userType=getUserType($UserId);
	if($userType =='ADMIN')
		header("location:../menu/adminMenu.php"); // redirect to admin page
	else if($userType =='STAFF')
		header("location:../menu/staffMenu.php"); // redirect to staff menu page
	}
else {
	echo'<div class="w3-center w3-container" style="width:400px; margin:auto">';
	echo "<center><br><br><div class='w3-center w3-container w3-red w3-margin w3-padding'><b><br>Wrong User Id or Password !!!<br><br></b>";
	echo'</div>';
	echo '<br><br><br><a class="w3-text-blue" href="../mainMenu.php"><b>Try Again</b></a>';
	}
?>
	
