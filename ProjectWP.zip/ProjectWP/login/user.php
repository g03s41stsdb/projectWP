<?php
//user.php
//=================== validatePassword
function validatePassword($UserId,$password)
{
$con=mysqli_connect("localhost","web412023","web412023","g03s41stsdb");
if(!$con)
	{
	echo  mysqli_connect_error(); 
	exit;
	}
$sql= "SELECT * FROM users where UserId = '".$UserId ."' and password ='".$password."'";
$result=mysqli_query($con,$sql);
$count=mysqli_num_rows($result); //check how many matching record - should be 1 if correct
if($count == 1){
	return true;//username and password is valid
}
else
	{
	return false; //invalid password
	}
	}

//=================== getUserType
function getUserType($UserId)
{
$con=mysqli_connect("localhost","web412023","web412023","g03s41stsdb");
if(!$con)
	{
	echo  mysqli_connect_error(); 
	exit;
	}
$sql= "SELECT * FROM users where UserId = '".$UserId ."'";
$result=mysqli_query($con,$sql);
$count=mysqli_num_rows($result); //check how many matching record - should be 1 if correct
if($count == 1){
	$row = mysqli_fetch_assoc($result);
	$userType=$row['userType'];
	return $userType;
	}
 }

?>